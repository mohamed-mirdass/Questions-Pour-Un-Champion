(() => {
  const TRANSITION_DURATION = 380;

  function ensureOverlay() {
    let el = document.getElementById('pageTransition');
    if (!el) {
      el = document.createElement('div');
      el.id = 'pageTransition';
      el.innerHTML = `
        <div class="pt-logo">
          <div class="pt-line1">QUIZ ARENA</div>
          <div class="pt-line2" id="ptDestLabel">Chargement...</div>
        </div>
        <div class="pt-bar"><span></span></div>
        <div class="pt-dots"><span></span><span></span><span></span></div>
      `;
      document.body.appendChild(el);
    }
    return el;
  }

  const overlay = ensureOverlay();

  const PAGE_LABELS = {
    'index.html':      'Accueil',
    'game.html':       'Partie en cours',
    'tournament.html': 'Tournoi',
    'mission.html':    'Mission Speedrun',
    'history.html':    'Historique',
    'results.html':    'Résultats',
    'rules.html':      'Règles du jeu',
  };

  function getPageLabel(href) {
    const filename = href.split('/').pop().split('?')[0];
    return PAGE_LABELS[filename] || 'Quiz Arena';
  }

  function showOverlay(label) {
    const labelEl = document.getElementById('ptDestLabel');
    if (labelEl) labelEl.textContent = label || 'Chargement...';
    overlay.classList.add('show');
    document.body.style.overflow = 'hidden';
  }

  function hideOverlay() {
    overlay.classList.add('hide');
    setTimeout(() => {
      overlay.classList.remove('show', 'hide');
      document.body.style.overflow = '';
    }, TRANSITION_DURATION);
  }

  window.addEventListener('load', () => {
    document.body.classList.add('page-entering');
    showOverlay(document.title.replace(' - Quiz Arena', '').replace('Quiz Arena', 'Accueil'));
    setTimeout(() => {
      hideOverlay();
      document.body.classList.remove('page-entering');
      document.body.classList.add('page-entered');
    }, 320);
  });

  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]');
    if (!a) return;
    const href = a.getAttribute('href');
    if (!href) return;
    if (href.startsWith('http') || href.startsWith('#') || href.startsWith('mailto')) return;
    if (a.target === '_blank') return;
    e.preventDefault();
    const label = getPageLabel(href);
    showOverlay(label);
    setTimeout(() => { window.location.href = href; }, TRANSITION_DURATION - 60);
  });

  window.addEventListener('DOMContentLoaded', () => {
    const _origShowScreen = window.showScreen;
    if (typeof _origShowScreen === 'function') {
      window.showScreen = function(id) {
        const routes = {
          homeScreen: 'index.html',
          gameScreen: 'game.html',
          missionScreen: 'mission.html',
          historyScreen: 'history.html',
          resultsScreen: 'results.html',
        };
        const labels = {
          homeScreen: 'Accueil', gameScreen: 'Partie', missionScreen: 'Mission',
          historyScreen: 'Historique', resultsScreen: 'Résultats'
        };
        if (routes[id] && !document.getElementById(id)) {
          showOverlay(labels[id] || 'Chargement...');
          setTimeout(() => { window.location.href = routes[id]; }, TRANSITION_DURATION - 60);
          return;
        }
        _origShowScreen(id);
      };
    }
  });

})();
